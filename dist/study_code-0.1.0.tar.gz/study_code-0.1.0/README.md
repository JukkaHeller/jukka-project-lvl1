[![Maintainability](https://api.codeclimate.com/v1/badges/045310a6781a92453cd4/maintainability)](https://codeclimate.com/github/JukkaHeller/jukka-project-lvl1/maintainability)
