[![Maintainability](https://api.codeclimate.com/v1/badges/045310a6781a92453cd4/maintainability)](https://codeclimate.com/github/JukkaHeller/jukka-project-lvl1/maintainability)


1. **brain_even game** - *guess is given number even or not*
[![asciicast](https://asciinema.org/a/Hnc4RdBJWTVvkBDbmkrTisM3l.svg)](https://asciinema.org/a/Hnc4RdBJWTVvkBDbmkrTisM3l)

2. **brain_calc game** - *make some trivial calculations*
[![asciicast](https://asciinema.org/a/EBbX3EU2YVieIsQ34i8Edsrwg.svg)](https://asciinema.org/a/EBbX3EU2YVieIsQ34i8Edsrwg)
